
function mostrarSecao(id, linkClicando){
  document.querySelectorAll('main section').forEach(sec =>{
    sec.classList.remove("visivel")
  });
  document.getElementsById(id).classList.add('visivel');
  linkClicando.classList.add('ativo');
}